Staffing Intelligence App — Chat Handoff Document
Last updated: Session 13 complete — Active Sprint cleared (#109, #122, #108, #106, #127), hygiene pass done (18 issues triaged, #110/#111 closed as duplicates), new issues logged (#124–#128), all docs updated. Next: Soon queue starting with #120, #121, #104.

---

## Session tracker

Active sessions are tracked in `session_tracker.md` in the repo root.
- Start each session by opening it and copying the session template
- Check off tasks as you go
- Commit it with the rest of the session's changes
- Archive completed sessions in the table at the bottom of the file

---

## What This App Is

Staffing Intelligence — a real-time staffing management platform for Varun's NetSuite consulting practice at Deloitte.

* Local web app at http://localhost:3000
* Node.js + Express backend, plain HTML/CSS/JS frontend
* Claude API (claude-sonnet-4-20250514) for AI features
* Supabase (Postgres) as data backbone — Excel fully retired
* 25 real consultants, real project data
* GitHub: https://github.com/varunprabhakar81/staffing-app (private)
* Railway (prod): https://staffing-app-production.up.railway.app

---

## Tech Stack

* server.js — Express backend + all API endpoints
* supabaseReader.js — Supabase data layer (dual-client: serviceClient + anonClient)
* claudeService.js — Claude API integration
* public/index.html, app.js, styles.css — frontend
* public/login.html — login page (dark theme, session-based auth)
* import-to-supabase.js — one-time Excel import script (keep for re-runs, uses serviceClient)
* session_tracker.md — session-by-session task checklist (repo root)
* Roadmap.md — full prioritized issue roadmap with effort estimates (repo root)
* NewChatPrompt.md — starter prompt for new Claude chat sessions (repo root)
* business/ExecutiveSummary_Source.md — executive summary content source
* business/build_deck.js — pptxgenjs script to regenerate executive PowerPoint deck

---

## Environment Variables (.env — required, all present and verified)

ANTHROPIC_API_KEY=your-key
PORT=3000
SUPABASE_URL=https://pybmpknumxshailjatok.supabase.co
SUPABASE_SERVICE_KEY=sb_secret_...
SUPABASE_ANON_KEY=your-anon-key
SESSION_SECRET=your-random-32-byte-hex
TENANT_ID=9762ee19-e1d1-48db-bc57-e96bee9ce2f8

Railway dashboard needs these 7 variables (PORT is injected automatically by Railway — do not set it):
- ANTHROPIC_API_KEY
- SUPABASE_URL
- SUPABASE_SERVICE_KEY
- SUPABASE_ANON_KEY
- SESSION_SECRET (generate a NEW one for prod — do not reuse local)
- TENANT_ID
- NODE_ENV=production

---

## KEY DESIGN PIVOT: No Explicit Edit Mode (Session 9)

The Edit Mode button is gone. Do not add it back.

New design (Airtable/Float model):
* Cells are always editable for admin and resource_manager — single click enters edit inline
* No mode toggle, no button, no state variable called _editMode or editMode
* The _hmCanEdit() function controls access — returns true for admin/resource_manager only
* project_manager and executive see read-only cells
* Pending changes tracked in _pendingStaffing map (key = "consultantId_projectId_weekKey")
* Amber dot (3px, #F59E0B) on cells with unsaved changes
* Floating save bar appears at bottom only when _pendingStaffing.size > 0
* Save bar: "X unsaved change(s)" label | Discard button | Save All button
* SSE fires while edits pending → toast appears, heatmap NOT overwritten
* Quick Fill bar shows when any row is expanded (_hmExpanded.size > 0), hidden otherwise
* Green success toast fires after Save All (added Session 13 — #127)

Total row cells are NOT editable:
* Cells with data-cell-type="emp-total" are read-only for all roles
* Clicking a Total cell auto-expands the consultant row and shows a pill tooltip
* Tooltip auto-dismisses after 2000ms or on outside click

Removed entirely:
* _editMode boolean variable
* toggleEditMode() function
* #hmEditToggle button element
* #conflictBanner fixed div (replaced by toast)
* All CSS classes tied exclusively to edit mode toggle

---

## Auth Architecture (#32 — complete)

* Supabase Auth with email/password
* Server-side sessions via express-session (httpOnly cookie, 8-hour maxAge)
* JWT contains tenant_id + role in app_metadata — set via custom_access_token_hook Postgres function
* RLS policies use auth.jwt() -> 'app_metadata' ->> 'tenant_id' (not current_setting)
* supabaseReader.js: serviceClient (service role, bypasses RLS) + anonClient (per-request JWT, RLS enforced)
* requireAuth middleware: protects all /api/* routes except /api/auth/*
* requireRole() middleware: enforces role-based access on sensitive routes
* Login page: public/login.html — POST /api/auth/login → session → redirect to index.html
* Logout: POST /api/auth/logout → session destroyed → redirect to login.html
* Auth guard: app.js checks /api/auth/me on load — 401 → redirect to login.html
* Startup cache warms using serviceClient (bypasses RLS) — logs "40 supply rows, 8 demand rows" on boot
* app.set('trust proxy', 1) — required for Railway reverse proxy + secure cookies in prod
* ALL read AND write endpoints now use serviceClient — do NOT revert to req.session.token

---

## RBAC (#62 + #105 — complete)

4 roles defined. Role stored in app_metadata.role in Supabase, stamped into JWT via custom_access_token_hook, stored in session at login, exposed on /api/auth/me.

VALID_ROLES: ['admin', 'resource_manager', 'project_manager', 'executive']
Stale roles removed: consultant, finance, recruiter — do not re-add these anywhere.

| Role | Access |
|---|---|
| admin | Full access + User Management + heatmap editing |
| resource_manager | All tabs except Settings. Heatmap editing available |
| project_manager | Overview, Needs, Ask Claude. Read-only heatmap (no Staffing tab) |
| executive | Overview + Ask Claude only. Read-only |

Tab visibility matrix:
| Tab | admin | resource_manager | project_manager | executive |
|---|---|---|---|---|
| Overview | ✅ | ✅ | ✅ | ✅ |
| Staffing | ✅ | ✅ | ❌ | ❌ |
| Needs | ✅ | ✅ | ✅ | ❌ |
| Ask Claude | ✅ | ✅ | ✅ | ✅ |
| Settings | ✅ | ❌ | ❌ | ❌ |
| Edit Mode button | REMOVED — no longer exists |

API route protection:
| Route | Roles allowed |
|---|---|
| GET /api/demand | admin, resource_manager, project_manager |
| GET /api/dashboard | admin, resource_manager, project_manager, executive |
| GET /api/heatmap | admin, resource_manager, project_manager, executive |
| GET /api/recommendations | admin, resource_manager, project_manager |
| GET /api/manage | admin, resource_manager |
| GET /api/supply | admin, resource_manager, project_manager |
| GET /api/employees | admin, resource_manager, project_manager |
| POST /api/save-staffing | admin, resource_manager |
| POST /api/supply/update | admin, resource_manager |
| GET /api/admin/users | admin |
| POST /api/admin/users/invite | admin |
| PATCH /api/admin/users/:id/role | admin |
| PATCH /api/admin/users/:id/deactivate | admin |
| PATCH /api/admin/users/:id/reactivate | admin |
| POST /api/admin/users/:id/resend-invite | admin |
| DELETE /api/admin/users/:id/invite | admin |

Note: /api/heatmap updated Session 13 to include executive (read-only) — fixes overview projects panel (#122).

---

## Schema

Key tables in Supabase (all tenant-scoped via tenant_id):

| Table | Purpose |
|---|---|
| consultants | People — name, level_id, location, capacity_hours_per_week, cost_rate_override, bill_rate_override, is_billable |
| resource_assignments | Assignments — consultant_id, project_id, week_ending, hours, is_billable |
| projects | Projects — name, client_id, status |
| clients | Clients |
| needs | Open staffing needs / demand |
| levels | Seniority levels |
| skill_sets | Skills lookup |
| consultant_skill_sets | Many-to-many consultant ↔ skills |
| need_skill_sets | Many-to-many need ↔ skills |

Important:
* employees array in app.js is built from consultants table — there is NO separate employees table
* is_billable exists on BOTH consultants (default per person) and resource_assignments (per assignment)
* ALL data operations use serviceClient — never req.session.token

---

## Critical Save Bug — Fixed Session 12

Root cause: POST /api/save-staffing and POST /api/supply/update were using req.session.token (null) — RLS blocked all writes. Saves returned 200 but nothing was written.

Fix: All write routes now use serviceClient. Do NOT revert.
Also added 1500ms delay before loadDashboard() post-save to allow Supabase propagation.

---

## isBillable Fix — Session 13 (#109)

Lookup chain on save: existing resource_assignment row → consultants.is_billable → true as last resort.
Previously defaulted to true for all new assignments because the fallback queried a non-existent employees table.
Fixed to query consultants table correctly. Verified end-to-end with test data.

---

## User Management (#63 + #101 — complete)

Admin-only panel under Settings tab.

Features:
* List all users in tenant — Name, Email, Role, Status, Last Login, Date Added
* Invite user — email invite (Supabase magic link) or temp password with complexity enforcement
* Temp password field is type="password" with show/hide eye toggle
* Change role — dropdown per row, PATCH /api/admin/users/:id/role (disabled for invited users)
* Deactivate — sets ban_duration: '87600h'. Row dims to opacity 0.6
* Reactivate — sets ban_duration: 'none' + shows green success toast
* Resend Invite — POST /api/admin/users/:id/resend-invite (invited users only)
* Cancel Invite — DELETE /api/admin/users/:id/invite (unconfirmed accounts only)

Password complexity: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{12,}$/

Role pill colors: admin=purple(#C9B8FF), resource_manager=blue(#A8C7FA), project_manager=mint(#A8E6CF), executive=yellow(#FFF3A3)

Test accounts (password: NewPassword123!):
* rm_test@test.com — resource_manager
* pm_test@test.com — project_manager
* exec_test@test.com — executive

---

## Toast System

showToast(msg, type = 'default', durationMs = 8000)

Variants:
* 'error'   → dark red bg (#7F1D1D), red left border (#EF4444), ✕ icon
* 'success' → dark green bg (#166534), green left border (#22C55E), ✓ icon
* 'default' → dark navy bg (#1A1D27), amber left border (#F59E0B), ⚠ icon

CSS class-based variants. Click to dismiss, auto-dismiss after durationMs.
All alert() calls replaced with showToast() — no native browser alerts anywhere.

---

## RLS Architecture

All 9 tenant tables have RLS enforced. All data operations use serviceClient (service role key) which bypasses RLS. Do not switch to user JWT for data reads or writes.

---

## Seeded Rate Data

| Level | Cost/hr | Bill/hr | Target Billable % |
|---|---|---|---|
| Analyst | $150 | $450 | 80% |
| Consultant | $200 | $550 | 80% |
| Senior Consultant | $300 | $750 | 75% |
| Manager | $350 | $788 | 70% |
| Senior Manager | $400 | $800 | 60% |
| Partner/Principal/Managing Director | $600 | $1,050 | 50% |

Non-Billable Projects: Unassigned, Assessment, Evaluation, ERP Evaluation, L2C Assessment, Secondment, Pre-Sales Support

---

## Design System

* Dark theme: #0F1117 page bg, #1A1D27 cards
* Pastel palette: Blue #A8C7FA, Mint #A8E6CF, Coral #FFB3B3, Yellow #FFF3A3, Purple #C9B8FF
* Inter font, white primary, #8892B0 secondary
* Left sidebar: 220px, collapsible to 56px

---

## Current App State

* Login page at /login.html — dark theme, email/password, inline error handling
* Auth guard on app load — redirects to login.html if no session
* Logout button at bottom of left sidebar
* 5 tabs: Overview, Staffing, Needs, Ask Claude, Settings (admin only)
* Overview: KPI cards, utilization by level, overallocation warning with tooltip + drilldown, top projects (all roles including executive), rolling off soon, needs attention
* Staffing: Always-on inline cell editing — row tints by utilization tier, horizon-aware bench red, current week column highlight, floating save bar, green success toast on save
* Quick Fill bar: appears when any row is expanded, hidden otherwise
* Needs: donut chart + expandable rows with AI match panel. Shows pipeline status + coverage status
* Ask Claude: dynamic suggested questions, text input, markdown responses
* Settings: User Management — active/invited/deactivated status pills, resend/cancel invite actions, collapsible deactivated section (admin only)
* SSE auto-refresh: fires after successful DB writes, pushes data-updated event to all clients
* All saves write to Supabase — ExcelJS fully removed
* Heatmap save: 1500ms delay post-save before loadDashboard() to allow Supabase propagation

---

## GitHub Milestones

| Milestone | GitHub ID | Issues |
|---|---|---|
| Active Sprint | #17 | ✅ Cleared Session 13 |
| Soon | #18 | #120, #121, #104, #114, #115, #61, #119, #124, #125, #126, #128 |
| V1 Stable | #19 | #123, #82, #83, #102, #103, #100, #116 |
| Phase 2 | #20 | #96, #99, #97, #98, #95, #66, #64, #43, #94, #117, #118 |

Triage complete — all 29 previously unmilesoned issues processed in Session 13.

---

## Issues Completed (30 total)

| Issue | Title | Session |
|---|---|---|
| #29 | Supabase schema setup | 2 |
| #30 | Supabase Excel import script | 2 |
| #31 | Supabase swap backend data layer | 3 |
| #17 | Auto-refresh SSE | 4 |
| #67 | Refresh button relocate | 4 |
| #77 | Merge Manage into Staffing: Hybrid Edit Mode | 5 |
| #84 | Terminology rename Supply/Demand | 6 |
| #87–#93 | Supabase Auth setup (#32) | 7 |
| #38 | Railway deploy | 8 |
| RLS | RLS tightening | 8 |
| #62 | RBAC role enforcement | 9 |
| #63 | User Management UI | 10 |
| #79 | Duplicate available hours | 10 |
| #80 | Legend swatch size | 10 |
| #81 | Favicon 404 | 10 |
| #101 | User Management invited/deactivated | 11 |
| B1 | RBAC guards on /api/supply and /api/employees | 11 |
| B2 | Heatmap end date dynamic | 11 |
| B7 | Temp password field masked | 11 |
| #112 | Replace alert() with showToast() | 12 |
| #107 | try/catch on changeUserRole/deactivateUser/reactivateUser | 12 |
| #113 | Success toast after reactivateUser + full toast variant system | 12 |
| #105 | Role gating UAT — all 4 roles verified | 12 |
| B-save | serviceClient fix for write routes — saves now persist | 12 |
| #109 | isBillable reads consultant default for new assignments | 13 |
| #122 | Executive overview projects — /api/heatmap now includes executive | 13 |
| #108 | Bell badge hardcoded to 4 — changed to 0 placeholder | 13 |
| #106 | Year-boundary week upsert — weekKeyToDate from meta replaces getFullYear() | 13 |
| #127 | Success toast after heatmap Save All | 13 |
| #110 | Closed as duplicate of #120 | 13 |
| #111 | Closed as duplicate of #121 | 13 |

---

## Build Order — Next Session

### Soon (start here):
1. #120 — Wire employee/project search input (#110 confirmed closed ✅)
2. #121 — Wire week selector dropdown (#111 confirmed closed ✅)
3. #104 — Settings tab styling inconsistencies
4. #114 — Deactivated section expand default logic
5. #115 — Tooltip on disabled role select
6. #128 — Total row expand + focus first cell (1–2h)
7. #61 — Comprehensive drilldown review across all tabs (3–4h)
8. #124 — Add new project assignment from heatmap (3–4h)
9. #119 — Review vs #125 before starting — close as duplicate if confirmed
10. #125 — Consultant profile editor — is_billable, capacity, rate overrides (4–6h)
11. #126 — Consultants management panel in Settings tab (6–8h)

### V1 Stable:
* #123 — Session role staleness (security — close before onboarding real users)
* #82 — UAT completion
* #83 — Remove test toast button
* #102 — Email verification flow
* #103 — Password strength policy
* #100 — User Management enhancements
* #116 — Document RBAC matrix in HANDOFF

### Phase 2 (after v1 stable):
* #96 — Tenant onboarding flow (the Phase 2 gate)
* #99 — Multi-role support
* #98 — Finance and Ops Dashboard
* #97 — Extended roles
* #95 — Light mode toggle
* #66 — Weekly snapshots
* #64 — Excel export/import
* #43 — Toggl Track integration
* #117 — Role switching
* #118 — Audit log
* #94 — UAT testing mode UI

---

## Key Technical Decisions

* No Edit Mode toggle — _hmCanEdit() is the single gating function. Never add editMode back.
* Pending changes variable name: _pendingStaffing (not pendingChanges)
* Total row cells: data-cell-type="emp-total" — never editable
* Capacity threshold: 45h/week
* Hours/Week input max: 100
* Heatmap end date: today + 90 days, rounded to next Saturday
* Bench tint horizon: only within 8 weeks of today (today + 56 days). Beyond that, 0h cells are neutral dark (#161820)
* ALL data operations use serviceClient — never req.session.token. Do not revert.
* SSE: named events (event: data-updated). If SSE fires while _pendingStaffing.size > 0, show toast only — do NOT re-render heatmap.
* Toast system: showToast(msg, type='default', durationMs=8000). CSS class-based variants. No inline styles.
* isBillable on save: prefer existing assignment row → consultants.is_billable → true as last resort (#109 fixed Session 13)
* employees array in app.js is built from consultants table — no separate employees table exists
* is_billable column exists on consultants (default) AND resource_assignments (per assignment)
* Invited user detection: last_sign_in_at === null AND not banned
* Cancel invite: deleteUser — only on unconfirmed accounts
* Resend invite: inviteUserByEmail — requires custom SMTP in Supabase for prod
* trust proxy: app.set('trust proxy', 1) — required for Railway
* Session: express-session, httpOnly, secure in prod, 8-hour maxAge, MemoryStore
* ExcelJS: fully removed
* Ban duration: '87600h'. Reactivate sets ban_duration: 'none'
* Password complexity: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{12,}$/
* VALID_ROLES: ['admin', 'resource_manager', 'project_manager', 'executive'] — no others
* app.js cache buster: currently v=26 — increment on every deploy with frontend changes
* Reactivate button uses inline onclick (not event delegation) — consistent with rest of app
* #119 and #125 may be duplicates — confirm before working on either
* Post-save: 1500ms delay before loadDashboard() to allow Supabase write propagation
* D1 is now formally tracked as #123
* /api/heatmap now includes executive (read-only) — updated Session 13

---

## Railway Deploy Checklist

- [ ] Verify latest commit is deployed (check Railway dashboard)
- [ ] Hard refresh with Ctrl+Shift+R after deploy
- [ ] Increment app.js?v= cache buster in index.html on every frontend change (currently v=26)
- [ ] Log out and back in after any JWT hook changes
- [ ] Set all 7 env vars in Railway dashboard
- [ ] Verify: Railway URL → redirects to login.html
- [ ] Verify: login → all tabs load with data
- [ ] Verify: executive login → Overview projects panel populates
- [ ] Verify: click a heatmap cell → input appears immediately (admin/resource_manager only)
- [ ] Verify: make a heatmap edit → Save All → green toast → hard refresh → change persists
- [ ] Verify: logout → redirects to login.html
- [ ] Note: Resend Invite requires custom SMTP in Supabase Auth dashboard

---

## CC Workflow Reminder

cd staffing-app
taskkill /F /IM node.exe   # Terminal 2 only
claude                      # Terminal 1 — start Claude Code
node server.js              # Terminal 2 — restart server after changes

Commit and push:
git add -A
git commit -m "feat: <issue title> (#XX)"
git push origin main

Railway auto-deploys from GitHub on every push to main. Allow 1-3 min for build.

---

## New Chat Starter Prompt

See NewChatPrompt.md in the repo root for the full starter prompt to paste into a new Claude chat.

---

## Notes
- Update HANDOFF reference to latest file at start of each session
- Update session_tracker.md at start and end of each session
- Rules in NewChatPrompt.md are permanent — do not remove them
- business/ folder contains executive summary source and deck builder — .pptx output is gitignored
